import org.w3c.dom.Element;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import java.util.List;
import java.util.ArrayList;
import javax.xml.parsers.*;

public class XMLClass {
	public static void main(String[] args) throws Exception{
		DocumentBuilderFactory a = DocumentBuilderFactory.newInstance();
		DocumentBuilder b = a.newDocumentBuilder();
		Document x = b.parse(ClassLoader.getSystemResourceAsStream("lab.xml"));
		List<buku> lists = new ArrayList<>();
		
		NodeList nd = x.getDocumentElement().getChildNodes();
		for(int i = 0;i < nd.getLength();i++){
			Node c = nd.item(i);
			if (c instanceof Element){
				buku bk = new buku();
				NodeList childs = c.getChildNodes();
				for(int j = 0; j<childs.getLength();j++){
					Node cN = childs.item(j);
					
					if(cN instanceof Element){
						String content = cN.getLastChild().getTextContent().trim();
						switch(cN.getNodeName()){
							case "judul":
								bk.judul = content; break;
							case "pengarang":
								bk.pengarang = content; break;
							case "penerbit":
								bk.penerbit = content; break;
							case "tahun":
								bk.tahun = new Integer(content); break;
						}
					}
				}
				lists.add(bk);
			}			
		}
		
		for(buku bku : lists){
			System.out.print(bku.toString());
		}
	}
}

class buku{
	String judul;
	String pengarang;
	String penerbit;
	Integer tahun;
	
	@Override
	public String toString(){
		return judul+" -- " +pengarang+" ("+penerbit+", "+tahun+")\n";
	}
}
